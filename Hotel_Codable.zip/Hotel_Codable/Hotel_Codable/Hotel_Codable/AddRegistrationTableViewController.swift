import UIKit

class AddRegistrationTableViewController: UITableViewController, SelectRoomTypeTableViewControllerDelegate {
    
    func selectRoomTypeTableViewController(didselect roomtype: RoomType) {
        self.roomType = roomtype
        updateRooms()
    }
    

    @IBOutlet weak var firstNameTextField: UITextField!
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    
    @IBOutlet weak var checkInDatePicker: UIDatePicker!
    @IBOutlet weak var checkOutDatePicker: UIDatePicker!
    @IBOutlet weak var checkIn: UILabel!
    @IBOutlet weak var checkOut: UILabel!
    
    @IBOutlet weak var adultCountLabel: UILabel!
    @IBOutlet weak var childrenCountLabel: UILabel!
    @IBOutlet weak var adultCountStepper: UIStepper!
    @IBOutlet weak var childrenCountStepper: UIStepper!
    
    @IBOutlet weak var roomTypeLabel: UILabel!
    @IBOutlet weak var wifiSwitch: UISwitch!
    
    @IBOutlet weak var noOfNights: UILabel!
    @IBOutlet weak var dateOfNoOfNights: UILabel!
    @IBOutlet weak var roomPrice: UILabel!
    @IBOutlet weak var displayRoomType: UILabel!
    @IBOutlet weak var wifiPrice: UILabel!
    @IBOutlet weak var usedWifi: UILabel!
    @IBOutlet weak var totalPrice: UILabel!
    
    var roomType: RoomType?
    
    var registration :Registration? {
        guard let roomType = roomType else {return nil}
        
        let firstName = firstNameTextField.text ?? ""
        let lastName = lastNameTextField.text ?? ""
        let email = emailTextField.text ?? ""
        let checkIn = checkInDatePicker.date
        let checkOut = checkOutDatePicker.date
        let noOfAdults = Int(adultCountStepper.value)
        let noOfChildren = Int(childrenCountStepper.value)
        let hasWifi = wifiSwitch.isOn
        
        return Registration(firstName: firstName, lastName: lastName, email: email, checkInDate: checkIn, checkOutDate: checkOut, noOfAdults: noOfAdults, noOfChildren: noOfChildren, wifi: hasWifi, roomType: roomType)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        let midnightToday = Calendar.current.startOfDay(for: Date())
        checkInDatePicker.minimumDate = midnightToday
        updateDateViews()
        updateNumberOfGuests()
        updatePriceDetails()
    }
    
    func updatePriceDetails() {
        let calendar = Calendar.current
        let checkInDate = checkInDatePicker.date
        let checkOutDate = checkOutDatePicker.date
        
        let components = calendar.dateComponents([.day], from: checkInDate, to: checkOutDate)
        let nights = components.day ?? 0
        
        noOfNights.text = "\(nights) night\(nights == 1 ? "" : "s")"
        
        // 2. Display check-in and check-out date range
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .none
        
        let checkInString = formatter.string(from: checkInDate)
        let checkOutString = formatter.string(from: checkOutDate)
        dateOfNoOfNights.text = "\(checkInString) - \(checkOutString)"
        
        let roomNightlyPrice = roomType?.price ?? 0
        roomPrice.text = "\(roomNightlyPrice * nights)"

        displayRoomType.text = "\(roomType?.name ?? "Not set") @ $\(roomType?.price ?? 0)/Night"
            // 4. Calculate wifi price
            let wifiCostPerNight = 10.0 // example wifi cost per night
            let wifiUsed = wifiSwitch.isOn
            usedWifi.text = wifiUsed ? "Yes" : "No"
            let wifiPriceTotal = wifiUsed ? Double(nights) * wifiCostPerNight : 0.0
            wifiPrice.text = String(format: "$%.2f", wifiPriceTotal)
            
            // 5. Calculate total price (room price * nights + wifi price)
            let total = (Double(nights) * Double(roomNightlyPrice)) + wifiPriceTotal
            totalPrice.text = String(format: "$%.2f", total)
    }

    
    @IBSegueAction func selectRoomType(_ coder: NSCoder) -> SelectRoomTypeTableViewController? {
        let selectRoomTypeController = SelectRoomTypeTableViewController(coder: coder)
        selectRoomTypeController?.delegate = self
        selectRoomTypeController?.roomType = roomType
        return selectRoomTypeController
    }
    
    func updateRooms(){
        if let roomtype = roomType{
            roomTypeLabel.text = roomtype.name
        }else{
            roomTypeLabel.text = "Not Set"
        }
        updatePriceDetails()
    }

    @IBAction func wifiSwitchChanged(_ sender: UISwitch) {
        updatePriceDetails()
    }
    
//    @IBAction func doneBarButtonTapped(_ sender: UIBarButtonItem) {
//        let firstName = firstNameTextField.text ?? ""
//        let lastName = lastNameTextField.text ?? ""
//        let email = emailTextField.text ?? ""
//        let checkIn = checkInDatePicker.date
//        let checkOut = checkOutDatePicker.date
//        let noOfAdults = Int(adultCountStepper.value)
//        let noOfChildren = Int(childrenCountStepper.value)
//        let hasWifi = wifiSwitch.isOn
//        let roomChoice = roomType?.name ?? "Not Set"
//        
//        print("Done tapped")
//        print(firstName)
//        print(lastName)
//        print(email)
//        print(checkIn)
//        print(checkOut)
//        print(noOfAdults)
//        print(noOfChildren)
//        print(hasWifi)
//        print(roomChoice)
//    }
//    
    
    @IBAction func chnageDates(_ sender: UIDatePicker) {
        updateDateViews()
    }
    
    func updateDateViews(){
        checkIn.text = checkInDatePicker.date.formatted(date: .abbreviated, time: .omitted)
        checkOut.text = checkOutDatePicker.date.formatted(date: .abbreviated, time: .omitted)
        
        checkOutDatePicker.minimumDate = Calendar.current.date(byAdding: .day, value: 1, to: checkInDatePicker.date)
        updatePriceDetails()
    }
    
    let checkInDatePickerCellIndexPath = IndexPath(row: 1, section: 1)
    let checkOutDatePickerCellIndexPath = IndexPath(row: 3, section: 1)
    
    var isCheckInDatePickerVisible: Bool = false{
        didSet{
            checkInDatePicker.isHidden = !isCheckInDatePickerVisible
        }
    }
    
    var isCheckOutDatePickerVisible: Bool = false{
        didSet{
            checkOutDatePicker.isHidden = !isCheckOutDatePickerVisible
        }
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        switch indexPath{
            
            case checkInDatePickerCellIndexPath where
            isCheckInDatePickerVisible == false:
                return 0
            
            case checkOutDatePickerCellIndexPath where
            isCheckOutDatePickerVisible == false:
                return 0
            
            default:
                return UITableView.automaticDimension
        }
    }
    
    override func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath{
        case checkInDatePickerCellIndexPath:
            return 190
            
        case checkOutDatePickerCellIndexPath:
            return 190
            
        default:
            return UITableView.automaticDimension
        }
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let checkInDateLabelCellIndexPath = IndexPath( row:0, section:1)
        
        let checkOutDateLabelCellIndexPath = IndexPath( row:2, section:1)
        
        if(indexPath == checkInDateLabelCellIndexPath && isCheckOutDatePickerVisible == false){
            
            isCheckInDatePickerVisible.toggle()
            
        }else if(indexPath == checkOutDateLabelCellIndexPath && isCheckInDatePickerVisible == false){
            isCheckOutDatePickerVisible.toggle()
            
        }else if(indexPath == checkInDateLabelCellIndexPath || indexPath == checkOutDateLabelCellIndexPath){
            isCheckInDatePickerVisible.toggle()
            isCheckOutDatePickerVisible.toggle()
            
        }else{
            return
        }
        tableView.beginUpdates()
        tableView.endUpdates()
    }
    
    func updateNumberOfGuests(){
        adultCountLabel.text = "\(Int(adultCountStepper.value))"
        childrenCountLabel.text = "\(Int(childrenCountStepper.value))"
    }
    
    
    @IBAction func stepperValueChanged(_ sender: UIStepper) {
        updateNumberOfGuests()
    }
    
    
    /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
