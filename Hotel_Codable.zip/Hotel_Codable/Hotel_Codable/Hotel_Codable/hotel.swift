//
//  hotel.swift
//  Hotel_Codable
//
//  Created by Student on 27/08/25.
//

import Foundation

struct Registration{
    var firstName: String
    var lastName: String
    var email: String
    
    var checkInDate: Date
    var checkOutDate: Date
    var noOfAdults: Int
    var noOfChildren: Int
    
    var wifi: Bool
    var roomType: RoomType
}


